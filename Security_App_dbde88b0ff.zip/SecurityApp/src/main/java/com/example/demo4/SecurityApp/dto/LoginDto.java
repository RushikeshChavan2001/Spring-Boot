package com.example.demo4.SecurityApp.dto;

import lombok.Data;

@Data
public class LoginDto {
    String email;
    String password;
}
